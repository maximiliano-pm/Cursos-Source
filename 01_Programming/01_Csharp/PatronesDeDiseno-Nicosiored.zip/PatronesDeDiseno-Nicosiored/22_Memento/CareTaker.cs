﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _22_Memento
{
    class CareTaker
    {
        private Memento memento;
        public Memento Memento { get => memento; set => memento = value; }
    }
}
