﻿using System;

namespace _22_Memento
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos el originador
            Originador auto = new Originador("March", 2019, 250000);
            auto.Mostrar();
            // Creamos el CareTaker
            CareTaker ct = new CareTaker();
            // Guardamos el estado
            ct.Memento = auto.CreaMemento();
            // Modificamos el objeto
            auto.Nombre = "Vocho";
            auto.Modelo = 1970;
            auto.Costo = 35000;
            auto.Mostrar();
            // Restaurando el estado anterior
            auto.Restaura(ct.Memento);
            auto.Mostrar();

            Console.ReadKey();
        }
    }
}
