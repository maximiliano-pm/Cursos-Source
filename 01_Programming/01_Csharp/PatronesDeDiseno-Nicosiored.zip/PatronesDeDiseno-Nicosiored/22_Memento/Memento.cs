﻿using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace _22_Memento
{
    class Memento
    {
        // El modificador de acceso internal solo da accesa a las clases que estan en el mismo assembly
        internal void Salvar(Originador objeto)
        {
            BinaryFormatter formateador = new BinaryFormatter();
            Stream miStream = new FileStream("Autos.aut", FileMode.Create, FileAccess.Write, FileShare.None);
            formateador.Serialize(miStream, objeto);
            miStream.Close();
            Console.WriteLine("Se ha salvado");
        }
        internal Originador Restaurar()
        {
            BinaryFormatter formateador = new BinaryFormatter();
            Stream miStream = new FileStream("Autos.aut", FileMode.Open, FileAccess.Read, FileShare.None);
            // Type caste ya que Deseraliza devuelve un objeto de tipo Object
            Originador temp = (Originador)formateador.Deserialize(miStream);
            miStream.Close();
            Console.WriteLine("Se ha restaurado");
            return temp;
        }
    }   
}