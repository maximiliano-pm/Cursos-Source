﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _14_Template
{
    interface IPrimitiva
    {
        double Decorar(int cantidad);
        double Empacar(int cantidad);
    }
}
