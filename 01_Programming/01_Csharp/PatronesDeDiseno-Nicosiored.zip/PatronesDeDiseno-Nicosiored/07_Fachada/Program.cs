﻿using System;
using Subsistemas;

namespace _07_Fachada
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos la instancia de la fachada
            CFachada fachada = new CFachada();

            // Hacemos uso de los subsistemas a traves de la interfaz
            // sencilla de la fachada
            fachada.Compra();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-------------------");

            fachada.Compra();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-------------------");

            fachada.Compra();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-------------------");

            fachada.Compra();
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine("-------------------");

            Console.ReadKey();
        }
    }
}
