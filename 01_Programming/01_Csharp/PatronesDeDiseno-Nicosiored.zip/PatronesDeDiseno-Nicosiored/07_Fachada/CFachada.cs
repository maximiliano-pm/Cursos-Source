﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Subsistemas
{
    class CFachada
    {
        // Estos son los subsistemas que se estan utilizando
        private CSistemaCompra compra = new CSistemaCompra();
        private CSubsistemaAlmacen almacen = new CSubsistemaAlmacen();
        private CSubsistemaEnvio envio = new CSubsistemaEnvio();

        // Este metodo es usado para realizar de forma sencilla una operacion
        // mas compleja que requiere de uno o varios subsistemas
        public void Compra()
        {
            if (compra.Comprar())
            {
                if (almacen.SacarAlmacen())
                {
                    envio.EnviarPedido();
                }
            }
        }
    }
}
