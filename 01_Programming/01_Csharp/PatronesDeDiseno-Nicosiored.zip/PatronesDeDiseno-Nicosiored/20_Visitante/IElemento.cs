﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _20_Visitante
{
    interface IElemento
    {
        void Aceptar(IVisitante pVisitante);
    }
}
