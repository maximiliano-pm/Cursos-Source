﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _23_MVC
{
    interface IVistaAuto
    {
        void DespliegaAuto(Auto pAuto);
        int SolicitaEntrada();
    }
}
