﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _13_Estado
{
    interface IEstado
    {
        void Trabajar();
        void CortarFuego();
        void PonerCombustible();
        void ForzarFuego();
    }
}
