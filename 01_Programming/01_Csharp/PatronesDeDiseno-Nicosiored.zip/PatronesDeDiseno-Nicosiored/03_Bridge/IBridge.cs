﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _03_Bridge
{
    // Esta es la interface que las implementaciones deben de mostrar
    interface IBridge
    {
        void MostrarTotales(Dictionary<string, double> pProductos);
        void ListarProductos(Dictionary<string, double> pProductos);
    }
}
