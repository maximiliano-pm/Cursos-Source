﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _06_Adaptador
{
    // Esta es la interfaz que conoce el cliente
    interface ITarget
    {
        int Sumar(int pA, int pB);
    }
}
