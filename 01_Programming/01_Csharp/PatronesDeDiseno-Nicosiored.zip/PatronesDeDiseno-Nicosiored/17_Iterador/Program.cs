﻿using System;

namespace _17_Iterador
{
    class Program
    {
        static void Main(string[] args)
        {
            CContenedora datos = new CContenedora();
            foreach (int valor in datos)
            {
                Console.WriteLine(valor);
            }
            Console.ReadKey();
        }
    }
}
