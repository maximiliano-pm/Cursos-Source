﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _12_Builder
{
    class BuilderDeportivo : IBuilder
    {
        private Producto auto = new Producto();
        public void ConstrulleMotor()
        {
            auto.ColocarMotor(new MotorGrande());
        }
        public void ConstrulleLlantas()
        {
            auto.ColocarLlantas(new LlantasSuper());
        }
        public void ConstrulleCarroceria()
        {
            auto.ColocarCarroceria(new CarroceriaEspecial());
        }
        public Producto ObtenProducto()
        {
            return auto;
        }
    }
}
