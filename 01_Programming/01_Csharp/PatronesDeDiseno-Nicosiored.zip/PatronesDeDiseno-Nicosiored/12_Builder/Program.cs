﻿using System;

namespace _12_Builder
{
    class Program
    {
        static void Main(string[] args)
        {
            Director miDirector = new Director();
            // Construimos un auto economico
            BuilderNormal normal = new BuilderNormal();
            miDirector.Construye(normal);
            //Obtenemos el auto
            Producto auto1 = normal.ObtenProducto();
            auto1.MostrarAuto();
            Console.WriteLine("------");
            // Construimos auto deportivo
            BuilderDeportivo deportivo = new BuilderDeportivo();
            miDirector.Construye(deportivo);
            // Obtenemos el auto
            Producto auto2 = deportivo.ObtenProducto();
            auto2.MostrarAuto();
            Console.ReadKey();
        }
    }
}
