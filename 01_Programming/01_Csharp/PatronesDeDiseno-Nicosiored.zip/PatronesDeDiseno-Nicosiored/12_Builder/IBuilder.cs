﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _12_Builder
{
    interface IBuilder
    {
        void ConstrulleMotor();
        void ConstrulleCarroceria();
        void ConstrulleLlantas();
    }
}
