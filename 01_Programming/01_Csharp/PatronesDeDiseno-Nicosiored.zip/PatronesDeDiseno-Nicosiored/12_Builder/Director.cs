﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _12_Builder
{
    class Director
    {
        public void Construye(IBuilder pConstructor)
        {
            // Aqui el Director indica los pasos para hacer la construccion
            // Pero el constructor es el que se encarga de construir segun
            // esta espeficicacion
            pConstructor.ConstrulleMotor();
            pConstructor.ConstrulleCarroceria();
            pConstructor.ConstrulleLlantas();
        }
    }
}
