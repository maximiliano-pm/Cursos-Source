﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _15_Responsabilidad
{
    class Propietario : IHandler
    {
        public double CalculaPrecioFinal(int pCantidad, double pPrecio)
        {
            Console.WriteLine("Con el propietario");
            // Si son mas de 20 articulos o mas de 20000 en ventas
            // pasa al jefe de piso
            double total = 0;
            // Damos un 15% de descuento
            total = pCantidad * pPrecio * 0.85;            
            return total;
        }
    }
}
