﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _15_Responsabilidad
{
    interface IHandler
    {
        double CalculaPrecioFinal(int pCantidad, double pPrecio);
    }
}
