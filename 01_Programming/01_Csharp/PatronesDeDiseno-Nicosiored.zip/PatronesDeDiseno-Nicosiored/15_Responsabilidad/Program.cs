﻿using System;

namespace _15_Responsabilidad
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos la cadena
            Propietario elPropietario = new Propietario();
            JefePiso elJefe = new JefePiso(elPropietario);
            Vendedor elVendedor = new Vendedor(elJefe);
            int cantidad = 150;
            double precio = 1000;
            double total = 0;
            total = elVendedor.CalculaPrecioFinal(cantidad, precio);
            Console.WriteLine("Total {0}, con descuento {1}", cantidad * precio, total);
            Console.ReadLine();
        }
    }
}
