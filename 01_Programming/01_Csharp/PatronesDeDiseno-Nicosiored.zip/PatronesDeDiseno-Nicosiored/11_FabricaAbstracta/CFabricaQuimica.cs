﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _11_FabricaAbstracta
{
    class CFabricaQuimica : IFabrica
    {
        private IProductoLeche leche;
        private IProductoSaborizante sabor;
        public IProductoLeche ObtenProductoLeche { get => leche; set => leche = value; }
        public IProductoSaborizante ObtenSabor { get => sabor; set => sabor = value; }

        public void crearProductos()
        {
            Console.WriteLine("Estamos produciendo tu malteada");
            leche = new CLecheVaca();
            sabor = new CSaborChocolate();
        }
    }
}
