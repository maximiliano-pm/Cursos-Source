﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _11_FabricaAbstracta
{
    // Interfaz para la leche
    interface IProductoLeche
    {
        void producir();
        string obtenDatos();
    }
}
