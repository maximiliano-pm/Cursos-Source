﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _11_FabricaAbstracta
{
    interface IFabrica
    {
        void crearProductos();
        IProductoLeche ObtenProductoLeche { get; }
        IProductoSaborizante ObtenSabor { get; }
    }
}
