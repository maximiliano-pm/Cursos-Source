﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _00_Estrategia
{
    class CResta : IOperacion
    {
        public double operacion(double a, double b)
        {
            return a - b;
        }
    }
}
