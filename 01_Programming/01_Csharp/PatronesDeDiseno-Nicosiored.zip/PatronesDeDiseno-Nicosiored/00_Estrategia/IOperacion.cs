﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _00_Estrategia
{
    interface IOperacion
    {
        double operacion(double a, double b);
    }
}
