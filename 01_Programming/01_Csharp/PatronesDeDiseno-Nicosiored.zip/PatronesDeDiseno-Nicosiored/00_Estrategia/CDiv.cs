﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _00_Estrategia
{
    class CDiv : IOperacion
    {
        public double operacion(double a, double b)
        {
            return a / b;
        }
    }
}
