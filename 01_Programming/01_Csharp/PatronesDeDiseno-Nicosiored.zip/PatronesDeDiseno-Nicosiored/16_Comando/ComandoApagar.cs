﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _16_Comando
{
    class ComandoApagar : IComando
    {
        Automovil auto;
        public ComandoApagar(Automovil pAuto)
        {
            auto = pAuto;
        }
        public void ejecutar()
        {            
            auto.Apagar();
        }
    }
}
