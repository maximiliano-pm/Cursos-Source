﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _16_Comando
{
    class ComandoApagarAlarma : IComando
    {
        Automovil auto;
        public ComandoApagarAlarma(Automovil pAuto)
        {
            auto = pAuto;
        }
        public void ejecutar()
        {
            auto.QuitarAlarma();
        }
    }
}
