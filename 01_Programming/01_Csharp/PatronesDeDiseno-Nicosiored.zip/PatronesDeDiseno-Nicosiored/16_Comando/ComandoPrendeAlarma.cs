﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _16_Comando
{
    class ComandoPrendeAlarma : IComando
    {
        Automovil auto;
        public ComandoPrendeAlarma(Automovil pAuto)
        {
            auto = pAuto;
        }
        public void ejecutar()
        {
            auto.ColocarAlarma();
        }
    }
}
