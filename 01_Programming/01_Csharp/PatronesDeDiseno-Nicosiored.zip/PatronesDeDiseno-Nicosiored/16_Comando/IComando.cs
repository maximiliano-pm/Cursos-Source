﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _16_Comando
{
    interface IComando
    {
        void ejecutar();
    }
}
