﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _16_Comando
{
    class Automovil
    {
        public void Encender()
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Se ha encendido el auto");
        }
        public void Apagar()
        {
            Console.ForegroundColor = ConsoleColor.Gray;
            Console.WriteLine("Se apago el auto");
        }
        public void ColocarAlarma()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Alarme encendida");
        }
        public void QuitarAlarma()
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("Alarma apagada");
        }
    }
}
