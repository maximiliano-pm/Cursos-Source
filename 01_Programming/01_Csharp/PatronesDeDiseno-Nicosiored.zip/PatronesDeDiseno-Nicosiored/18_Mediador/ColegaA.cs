﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _18_Mediador
{
    class ColegaA : IColega
    {
        private Mediador mediador;
        private string nombre;
        public ColegaA(string pNombre, Mediador pMediador)
        {
            nombre = pNombre;
            // Tenemos la referencia al mediador
            mediador = pMediador;
            // Nos suscribimos
            mediador.Suscribir(Recibir);
        }
        public void Recibir(string emisor, string mensaje)
        {
            //Lleva a cabo la recepcion segun su estilo
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Soy {0}, recibi de {1} : {2}", nombre, emisor, mensaje);
        }
        public void Enviar(string mensaje)
        {
            // Aqui colocamos la logica para el envio de mensaje
            // No necesariamente debe de ser un parametro
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("Soy {0}, envio:{1}", nombre, mensaje);
            mediador.Enviar(nombre, mensaje);
        }
    }
}
