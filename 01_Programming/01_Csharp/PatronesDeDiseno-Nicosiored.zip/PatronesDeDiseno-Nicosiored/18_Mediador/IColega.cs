﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _18_Mediador
{
    interface IColega
    {
        void Recibir(string emisor, string mensaje);
        void Enviar(string mensaje);
    }
}
