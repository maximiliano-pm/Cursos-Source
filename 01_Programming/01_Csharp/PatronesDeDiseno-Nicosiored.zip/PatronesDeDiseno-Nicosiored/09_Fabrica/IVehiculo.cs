﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09_Fabrica
{
    interface IVehiculo
    {
        void Encender();
        void Acelerar();
        void Frenar();
        void Girar();
    }
}
