﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _09_Fabrica
{
    class CAuto : IVehiculo
    {
        public void Encender()
        {
            Console.WriteLine("Introduce la llave y girala");
        }
        public void Acelerar()
        {
            Console.WriteLine("Oprime el pedal del acelerador");
        }
        public void Frenar()
        {
            Console.WriteLine("Presiona el pedal de freno");
        }
        public void Girar()
        {
            Console.WriteLine("Toma el volante y giralo");
        }
    }
}
