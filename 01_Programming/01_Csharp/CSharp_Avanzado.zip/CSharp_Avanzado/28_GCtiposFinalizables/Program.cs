﻿using System;

namespace _28_GCtiposFinalizables
{
    class CPrueba
    {
        private int a;
        public CPrueba(int pA)
        {
            a = pA;
        }
        public override string ToString()
        {
            return string.Format("El valor es {0}", a);
        }
        // Tipos finalizables
        // Object tienen un metodo virtual Finalize()
        // Cuando se hace el override de Finalize tenemos un lugar donde llevar a cabo
        // la limpieza para la clase
        // No se puede invocar directamente, por que es un metodo protegido 
        // Lo invoca el recolector de basura antes de eleiminar el objeto de la memoria
        // No se puede hacer override de tipos estructura
        // Practicamente nunca haremos esto salvo que tengamos recursos no administrados
        // que necesiten ser eliminados manualmente: PInvoke, COM, memoria no administrada

        // No hacemos uso de override
        // Se utiliza el destructor para esto
        // Solo se puede usar en tipos Class no Struct
        ~CPrueba()
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("Aqui liberamos recursos no administrados");
            Console.Beep(600, 50);
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Obtenemos la cantidad de bytes en el Heap
            long bytesHeap = GC.GetTotalMemory(false);
            Console.WriteLine("El heap usa {0} bytes", bytesHeap);

            // Obtenemos la cantidad de generaciones, basada en 0 por eso +1
            int maximaGeneracion = GC.MaxGeneration + 1;
            Console.WriteLine("Se tienen {0} generaciones", maximaGeneracion);

            // Creamos una instancia
            CPrueba prueba1 = new CPrueba(5);
            bytesHeap = GC.GetTotalMemory(false);
            Console.WriteLine("El heap usa {0} bytes", bytesHeap);
            // Obtenemos la generacion de la instancia
            int generacionInstancia = GC.GetGeneration(prueba1);
            Console.WriteLine("La generacion de la instancia es {0}", generacionInstancia);

            // Forzar la recoleccion de basura
            // Solo hacerlo en situaciones especiales
            // Cuando la aplicacion entra a un bloque de codigo que no debe de ser
            // interrumpido por la recoleccion
            // La aplicacion creo una grancantidad de instancias y se necesita liberar la mayor cantidad de memoria posible

            GC.Collect();
            GC.WaitForPendingFinalizers();

            // Para recolectar de una generacion en particular
            GC.Collect(0);
            GC.WaitForPendingFinalizers();
        }
    }
}