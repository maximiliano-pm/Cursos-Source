﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Adicionar namespace
using System.Reflection;
namespace _44_AppDomain2
{
    class Program
    {
        static void Main(string[] args)
        {
            // Cuando un executable inicia el CLR lo coloca en el AppDomain
            // de default del proceso que lo alberga
            // Podemos tener acceso a ese AppDomain de default

            AppDomain AD = AppDomain.CurrentDomain;

            // Imprimimos la informacion que nos proporciona
            Console.WriteLine("Nombre del dominio: {0}", AD.FriendlyName);
            Console.WriteLine("ID del dominio en el proceso: {0}", AD.Id);
            Console.WriteLine("Directorio base del dominio: {0}", AD.BaseDirectory);

            // Verificamos si es el de default
            if (AD.IsDefaultAppDomain() == true)
                Console.WriteLine("Es el de default");
            else
                Console.WriteLine("No es el de default");

            // Podemos encontrar los assemblies que el AppDomain usa

            // Obtenemos los assemblies
            Assembly[] assemblies = AD.GetAssemblies();
            // Los recorremos
            foreach (Assembly assembly in assemblies)
            {
                Console.WriteLine("Nombre: {0}, version: {1}", assembly.GetName().Name, assembly.GetName().Version);
            }
            Console.ReadKey();

        }
    }
}
