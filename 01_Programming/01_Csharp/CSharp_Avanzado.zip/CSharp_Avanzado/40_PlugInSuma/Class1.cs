﻿using System;
// Adicionamos este namespace
using TiposPlugIn;

namespace PlugInSuma
{
    // No olvidar hacer la referencia a TiposPlugIn

        // Colocamos el atributo
        [CInfoPlugIn(Creador ="Nicosio", Informacion ="Regresa doble, dos operandos a sumar")]
    // Creamos la clase que implementa la interfaz
    public class CSuma : IPlugInMates
    {
        public double Calcular(double pA, double pB)
        {
            double r = pA + pB;
            return r;
        }
    }
}
