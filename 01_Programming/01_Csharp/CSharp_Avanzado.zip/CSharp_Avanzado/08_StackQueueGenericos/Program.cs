﻿using System;
using System.Collections.Generic;

namespace _08_StackQueueGenericos
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack<CPunto> puntosS = new Stack<CPunto>();

            puntosS.Push(new CPunto(3, 4));
            puntosS.Push(new CPunto(5, 7));
            puntosS.Push(new CPunto(9, 11));
            puntosS.Push(new CPunto(1, 4));

            foreach (CPunto p in puntosS)
                Console.WriteLine("->{0}", p);
            Console.WriteLine("--------------");

            // Hacemos un peek
            Console.WriteLine(puntosS.Peek());
            foreach (CPunto p in puntosS)
                Console.WriteLine("->{0}", p);
            Console.WriteLine("--------------");

            // Hacemos dos pop
            Console.WriteLine("Pop {0}",puntosS.Pop());
            Console.WriteLine("Pop {0}", puntosS.Pop());
            foreach (CPunto p in puntosS)
                Console.WriteLine("->{0}", p);
            Console.WriteLine("--------------");

            // Hacemos otro peek
            Console.WriteLine(puntosS.Peek());
            foreach (CPunto p in puntosS)
                Console.WriteLine("->{0}", p);
            Console.WriteLine("--------------");

            Queue<CPunto> puntosQ = new Queue<CPunto>();

            puntosQ.Enqueue(new CPunto(3, 4));
            puntosQ.Enqueue(new CPunto(7, 9));
            puntosQ.Enqueue(new CPunto(11, 2));

            foreach (CPunto p in puntosQ)
                Console.WriteLine("->{0}", p);
            Console.WriteLine("--------------");

            // Hacemos un peek
            Console.WriteLine(puntosQ.Peek());
            foreach (CPunto p in puntosQ)
                Console.WriteLine("->{0}", p);
            Console.WriteLine("--------------");

            // Hacemos dequeue
            Console.WriteLine("Dequeue {0}", puntosQ.Dequeue());
            Console.WriteLine("Dequeue {0}", puntosQ.Dequeue());
            foreach (CPunto p in puntosQ)
                Console.WriteLine("->{0}", p);
            Console.WriteLine("--------------");
        }
    }
    class CPunto
    {
        private int x, y;
        public CPunto(int px, int py)
        {
            x = px;
            y = py;
        }
        public override string ToString()
        {
            return string.Format("X={0}, Y={1}", x, y);
        }
    }
}
