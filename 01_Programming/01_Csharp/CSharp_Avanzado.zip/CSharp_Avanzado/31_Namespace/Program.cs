﻿using System;

// Agregamos estos namespace para poder usar los tipos definidos ahi
//using LasClases;
//using OtrasClases;

// Usando namespace anidados
using _31_Namespace.OtrasClases;
// Usando namespace anidados con alias
using otras = _31_Namespace.OtrasClases;

// Creamos un alias a las clases que nos den conflicto
using principal = LasClases.Clase1;
using secundaria = OtrasClases.Clase1;
namespace _31_Namespace
{
    class Program
    {
        static void Main(string[] args)
        {
            // Explica uso de namespace

            // La clase solo se puede instancias si usamos el namespace
            // Si tenemos los dos using el compilador no sabe cual usar
            //Clase1 ob1 = new Clase1();

            // O si usamos el nombre totalmente calificado
            // comentar el namespace
            //LasClases.Clase1 ob2 = new LasClases.Clase1();

            // Adicionamos el otro namespace
            // Hay conflicto si en los dos namespace se tienen clases con el mismo nombre
            //Clase1 ob1 = new Clase1();

            // Se resuelve usando el nombre totalmente calificado
            //LasClases.Clase2 ob3 = new LasClases.Clase2();
            //OtrasClases.Clase2 ob4 = new OtrasClases.Clase2();

            // Creacion de un alias para corregir problemas de
            // colision de nomres
            principal ob1 = new principal();
            secundaria ob2 = new secundaria();

            // Namespace anidados
            Clase1 miOnjeto = new Clase1();
            otras.Clase1 otroObjeto = new otras.Clase1();
        }
    }
}