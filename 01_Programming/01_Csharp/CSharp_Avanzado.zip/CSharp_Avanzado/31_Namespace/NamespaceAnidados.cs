﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _31_Namespace
{
    namespace LasClases
    {
        class Clase1
        {
            public Clase1()
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Saludos desde Clase1 LasClases");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        class Clase2
        {
            public Clase2()
            {
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine("Saludos desde Clase2 LasClases");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        class Clase3
        {
            public Clase3()
            {
                Console.WriteLine("Saludos desde Clase3");
            }
        }
    }
    // Creamos otro namespace
    namespace OtrasClases
    {
        class Clase1
        {
            public Clase1()
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Saludos desde Clase1 OtrasClases");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        class Clase2
        {
            public Clase2()
            {
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine("Saludos desde Clase2 OtrasClases");
                Console.ForegroundColor = ConsoleColor.White;
            }
        }
        class Clase3
        {
            public Clase3()
            {
                Console.WriteLine("Saludos desde Clase3 Otras");
            }
        }
    }
}
