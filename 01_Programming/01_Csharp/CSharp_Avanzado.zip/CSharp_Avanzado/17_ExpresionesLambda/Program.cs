﻿using System;
using System.Collections.Generic;

namespace _17_ExpresionesLambda
{
    class Program
    {
        static void Main(string[] args)
        {
            // Hacemos lo mismo que en elejemplo anterior pero con expresion lambda
            // Solo se pueden usar donde se haga uso de un metodo anonimo o un delegado
            // fuertementi tipificado

            // lista de parametros => instrucciones a realiar
            // El tipo de los parametros puede ser implicito o explicito (int i)

            List<int> numeros = new List<int>();
            numeros.AddRange(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 5, 4, 8, 11, 12, 3, 7, 20 });

            // Hacemos uso de la expresion lambda
            List<int> numPares = numeros.FindAll(i => (i % 2) == 0);

            // Mostramos los numeros
            foreach (int n in numPares)
                Console.WriteLine(n);

            Console.WriteLine("------------------");
            List<int> numeros1 = new List<int>();
            numeros1.AddRange(new int[] { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 5, 4, 8, 11, 12, 3, 7, 20 });

            // Hacemos uso de la expresion lambda
            List<int> numPares1 = numeros.FindAll((i) =>
            {
                if (i % 2 == 0)
                {
                    Console.WriteLine("Un par");
                    return true;
                }
                else
                {
                    Console.WriteLine("Un impar");
                    return false;
                }
            });
            // Mostramos los numeros
            foreach (int n in numPares1)
                Console.WriteLine(n);
        }
    }
}
