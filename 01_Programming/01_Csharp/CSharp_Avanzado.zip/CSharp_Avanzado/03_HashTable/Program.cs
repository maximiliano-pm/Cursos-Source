﻿using System;
using System.Collections;

namespace _03_HashTable
{
    class Program
    {
        static void Main(string[] args)
        {
            Hashtable miTabla = new Hashtable();

            // Adicionamos elementos
            miTabla.Add(123, "Hola");
            miTabla.Add(234, "Saludos");
            miTabla.Add(45, "Adios");
            miTabla.Add(567, "C#");
            miTabla.Add(12763, "Programacion");

            // Mostramos los elementos
            foreach (DictionaryEntry elemento in miTabla)
            {
                Console.WriteLine("({0}, {1})", elemento.Key, elemento.Value);
            }

            // Intentamos colocar un elemento con llave repetida
            //miTabla.Add(123, "Otro mas");

            // Cantidad de elementos
            Console.WriteLine(miTabla.Count);
            Console.WriteLine("-----");

            // Obtenemos el elemento de determinada llave
            Console.WriteLine(miTabla[567]);
            Console.WriteLine(miTabla[445]);
            Console.WriteLine("-----------");

            // Colocamos elemento en una llave
            miTabla[45] = "Avanzado";
            miTabla[300] = "Colecciones"; // Esto tambien adiciona
            foreach (DictionaryEntry elemento in miTabla)
            {
                Console.WriteLine("({0}, {1})", elemento.Key, elemento.Value);
            }
            Console.WriteLine("----------");

            // Verificar si hay un elemento
            Console.WriteLine(miTabla.Contains(567));
            Console.WriteLine(miTabla.Contains(335));
            Console.WriteLine("-------");

            // Eliminamos un elemento
            miTabla.Remove(234);
            foreach (DictionaryEntry elemento in miTabla)
            {
                Console.WriteLine("({0}, {1})", elemento.Key, elemento.Value);
            }
            Console.WriteLine("----------");

            foreach (int llave in miTabla.Keys)
            {
                Console.WriteLine(llave);
            }
            Console.WriteLine("----------");

            foreach (string valor in miTabla.Values)
            {
                Console.WriteLine(valor);
            }
        }
    }
}
