﻿using System;

namespace _15_FuncMetodoAnonimo
{
    class CPunto
    {
        public delegate void DelMensaje();
        public DelMensaje mensaje;

        private int x;
        private int y;
        public CPunto(int px, int py)
        {
            x = px;
            y = py;
        }
        public override string ToString()
        {
            return string.Format("X={0}, Y{1}", x, y);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Func funciona similar a Action, pero permite tipo de retorno
            int x = 5;
            int y = 9;
            // Definimos el delegado, el ultimo tipo listado es siempre el tipo de retorno
            Func<int, int, int> delFunc = new Func<int, int, int>(Suma);
            // Invocamos e imprimimos el resultado
            Console.WriteLine(delFunc(x, y));

            //===== METODO ANONIMO =====
            CPunto miPunto = new CPunto(5, 6);

            // Creamos el metodo anonimo para el delegado
            miPunto.mensaje += delegate ()
              {
                  Console.WriteLine("Estoy desde el metodo anonimo");
              };
            Console.WriteLine(miPunto.ToString());

            // Invocamos
            miPunto.mensaje();

            // Adicionamos otro
            miPunto.mensaje += delegate ()
            {
                Console.WriteLine("Este es otro metodo anonimo");
            };

            miPunto.mensaje();
        }
        // Este metodo es el handler para func
        static int Suma(int a, int b)
        {
            int r = 0;
            r = a + b;
            return r;
        }
    }
}
