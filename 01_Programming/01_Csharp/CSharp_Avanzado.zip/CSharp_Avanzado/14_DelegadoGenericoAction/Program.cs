﻿using System;

namespace _14_DelegadoGenericoAction
{
    // Creamos el delegado generico
    public delegate void miDelegado<T>(T p);
    class Program
    {
        static void Main(string[] args)
        {
            // Registramos y usamos el string
            miDelegado<string> delCadena = new miDelegado<string>(HandlerString);
            delCadena("Hola a todos");

            // Registramos y usamos el double
            miDelegado<double> delDouble = new miDelegado<double>(HandlerDouble);
            delDouble(58.7);

            // Action nos permite crear delegados en el momento, para un maximo de 16 parametros
            // pero el tipo de retorno debe de ser void
            int n = 5;
            string m = "Hola a todos";

            // Usamos action para registrar el handler con el delegado
            Action<string, int> delAction = new Action<string, int>(RepiteMensaje);
            // Invocamos el delegado
            delAction(m, n);            
        }
        // Handler para el caso string
        static void HandlerString(string p)
        {
            Console.WriteLine("Uso string como tipo y el valor es {0}", p);
        }
        // Handler para el caso double
        static void HandlerDouble(double p)
        {
            Console.WriteLine("Uso double como tipo y el valor es {0}", p);
        }
        // Este metodo es el handler para action
        static void RepiteMensaje(string pMensaje, int pVeces)
        {
            int n = 0;
            for (n = 0; n < pVeces; n++)
                Console.WriteLine(pMensaje);
        }
    }
}