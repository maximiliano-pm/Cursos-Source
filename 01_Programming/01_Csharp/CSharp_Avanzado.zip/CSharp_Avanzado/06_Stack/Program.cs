﻿using System;
using System.Collections;

namespace _06_Stack
{
    class Program
    {
        static void Main(string[] args)
        {
            Stack miStack = new Stack(); // LIFO

            // Agregamos elementos
            miStack.Push("Manzana");
            miStack.Push("Pera");
            miStack.Push("Ciruela");
            miStack.Push("Mango");

            // Iteramos el stack
            foreach (string fruta in miStack)
                Console.WriteLine("->{0}",fruta);
            Console.WriteLine("--------");

            // Hacemos pop
            Console.WriteLine(miStack.Pop());
            foreach (string fruta in miStack)
                Console.WriteLine("->{0}", fruta);
            Console.WriteLine("--------");

            // Hacemos peek
            Console.WriteLine(miStack.Peek());
            foreach (string fruta in miStack)
                Console.WriteLine("->{0}", fruta);
            Console.WriteLine("--------");

            // Cantidad de elementos
            Console.WriteLine(miStack.Count);
            Console.WriteLine("--------");
        }
    }
}