﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// En este nivel se colocan atributos que se colocaran en todos los elementos
// [assembly : CLSCompliant(true)]

namespace _37_Atributos
{
    // La clase debe de ser publica y sellada
    // Este atributo guarda el dato en el assembly
    public sealed class DatosAttribute : System.Attribute
    {
        string dato = "";
        public string Dato { get => dato; set => dato = value; }
        public DatosAttribute() { }
        public DatosAttribute(string pDato)
        {
            dato = pDato;
        }
    }
    //public enum AttributeTargets
    //{
    //    All, Assembly, Class, Constructor,
    //    Delegate, Enum, Event, Field, GenericParameter,
    //    Interface, Method, Module, Parameter,
    //    Property, ReturnValue, Struct
    //}
    //[AttributeUsage(AttributeTargets.Class | AttributeTargets.Struct)]

    //[Obsolete]
    //[Obsolete("Usa la nueva version CPrueba2")]
    class CPrueba
    {
        public CPrueba()
        {
            Console.WriteLine("Version 1");
        }
    }
    [Datos("Clase por Nicosio")]
    class CPrueba2
    {
        public CPrueba2()
        {
            Console.WriteLine("Version 2");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Atributos
            // Los hemos utiliado para "decorar" a las clases
            // Adicionan informacion al metadata del assembly 
            // Se pueden usar con clases, interfaces, estructuras, propiedades, metodos
            // Son clases que descienden de System.Atribute
            // [CLSCompliant], [Obsolete], [Serializable], [NonSerializable]
            // El compilador esta preparado para encontrar los atributos y actuar con lo que se deba hacer
            // Tienen un nombre corto y un nombre largo [Serializable] -> [SerializableAttribute]
            // Pueden o no recibir parametros dependiendo de sus constructores

            CPrueba miPrueba = new CPrueba();
            CPrueba2 miPrueba2 = new CPrueba2();
            Console.ReadKey();
        }
    }
}
