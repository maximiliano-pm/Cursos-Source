﻿using System;

namespace _24_ImplementacionExplicitaJerarquia
{
    interface IArea
    {
        void Calcular();
    }
    interface IPerimetro
    {
        void Calcular();
    }
    // Implementa dos interfaces que tienen metodos con el mismo nombre
    // Esto lo resolvemos con la implementacion explicita de interfaces
    class CCuadrado : IArea, IPerimetro
    {
        private int lado;
        public CCuadrado(int pLado)
        {
            lado = pLado;
        }
        // El acceso por defecto es public, no se puede cambiar
        void IArea.Calcular()
        {
            Console.WriteLine("Calcular area = {0}", lado * lado);
        }
        void IPerimetro.Calcular()
        {
            Console.WriteLine("Calcular perimetro = {0}", lado * 4);
        }
    }

    interface IMostrar
    {
        void MostrarDatos();
    }
    interface ICalcular : IMostrar
    {
        // Creamos la jerarquia de interfaces
        // Ahora ICalcular aparte de claculo tiene los metodos de IMostrar
        int Calculo(int a, int b);
    }
    // Ahora implementamos ICalcular que al tener jerarquia, tambien nos forza a
    // implementar IMostrar
    class CCsuma : ICalcular
    {
        private int a, b, r;

        // Implementacion de ICalcular
        public int Calculo(int pa, int pb)
        {
            a = pa;
            b = pb;
            r = a + b;
            return r;
        }
        // Implementacion de IMostrar por la jerarquia
        public void MostrarDatos()
        {
            Console.WriteLine("{0} + {1} = {2}", a, b, r);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Forma de implementar dos interfaces con el mismo nombre de metodo
            CCuadrado cuadro = new CCuadrado(5);
            //cuadro.   no aparece el metodo calcular
            ((IPerimetro)cuadro).Calcular();
            ((IArea)cuadro).Calcular();


            // Jerarquia de interfaces
            CCsuma miSuma = new CCsuma();
            // Metodo debido a ICalcular
            miSuma.Calculo(5, 3);
            // Metodo debido a la jerarquia en ICalcular
            miSuma.MostrarDatos();
        }
    }
}