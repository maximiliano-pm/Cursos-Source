﻿using System;

namespace _19_ConversionImplicitaTiposAnonimos
{
    class CComplejo
    {
        private int a;
        private int b;
        public int A { get => a; set => a = value; }
        public int B { get => b; set => b = value; }
        public CComplejo(int pa, int pb)
        {
            a = pa;
            b = pb;
        }
        public override string ToString()
        {
            return string.Format("{0} + {1}i", a, b);
        }
        // Creamos una conversion explicita a reales
        public static explicit operator CReal(CComplejo pi) // De CComplejo a CReal
        {
            CReal temp = new CReal();
            temp.R = pi.a;
            return temp;
        }
    }
    class CReal
    {
        private double r;
        public double R { get => r; set => r = value; }
        public CReal()
        {

        }
        public CReal(double pr)
        {
            r = pr;
        }
        public override string ToString()
        {
            return string.Format("r={0}", r);
        }
        // Creamos una conversion implicita de reales e imaginarios
        public static implicit operator CComplejo(CReal pR)
        {
            CComplejo temporal = new CComplejo((int)pR.r, 0);
            return temporal;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Conversion custom de tipo
            CComplejo im1 = new CComplejo(2, 3);

            // no se puede
            //CReal real1 = im1;

            // Tampoco se puede haste que coloquemos el explicit
            CReal real2 = (CReal)im1;
            Console.WriteLine(real2);

            // Aqui la conversion implicita
            CReal r3 = new CReal(3.5);
            CComplejo im2 = r3;
            Console.WriteLine(im2);

            // ===== TIPOS ANONIMOS =====
            // Creamos tipos anonimos
            // Crea un tipo temporal con atributos, propiedades, ToString

            // Creamos el tipo anonimo
            // Es una clase sellada, no tiene nombre y solo es de lectura
            var miCompu = new { Procesador = "i7", Memoria = 16, Graficos = "Intel" };

            // Imprimir la variable
            Console.WriteLine(miCompu);

            // Imprimimor un atributo
            Console.WriteLine("La compu tiene {0} de memoria", miCompu.Memoria);

            // No podemos modificar el atributo es de solo lectura
            //miCompu.Graficos = "nvidia";
        }
    }
}