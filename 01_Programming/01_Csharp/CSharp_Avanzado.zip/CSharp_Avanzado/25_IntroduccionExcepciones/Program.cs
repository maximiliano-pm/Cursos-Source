﻿using System;
using System.Collections;

namespace _25_IntroduccionExcepciones
{
    class CCaldera
    {
        private int tempMax = 120;
        private int tempActual = 0;
        private string marca = "";
        private bool funciona = true;
        public int Temperatura { get => tempActual; set => tempActual = value; }
        public string Marca { get => marca; set => marca = value; }
        public bool Funciona { get => funciona; }
        public CCaldera(string pMarca, int pTemp)
        {
            tempActual = pTemp;
            marca = pMarca;
        }

        // Hacemos trabajar la caldera, sin usar excepciones

        ////V1
        //public void Trabajar(int pAumento)
        //{
        //    if (funciona == false)
        //        Console.WriteLine("La caldera {0} esta descompuestoa", marca);
        //    else
        //    {
        //        tempActual += pAumento;
        //        Console.WriteLine("La temperatura actual es de {0}", tempActual);
        //        if (tempActual > tempMax)
        //        {
        //            Console.WriteLine("{0} supero la temperatura, tiene {1}", marca, tempActual);
        //            tempActual = tempMax;
        //            funciona = false;
        //        }
        //    }
        //}

        //// V2
        //public void Trabajar(int pAumento)
        //{
        //    if (funciona == false)
        //        Console.WriteLine("La caldera {0} esta descompuesta", marca);
        //    else
        //    {
        //        tempActual += pAumento;
        //        Console.WriteLine("La temperatura actual es de {0}", tempActual);
        //        if (tempActual > tempMax)
        //        {
        //            Console.WriteLine("{0} supero la temperatura, tiene {1}", marca, tempActual);
        //            tempActual = tempMax;
        //            funciona = false;
        //            //Lanzamos la excepcion
        //            throw new Exception(string.Format("La caldera {0} se sobrecalenta", marca));
        //        }
        //    }
        //}

        // V3
        public void Trabajar(int pAumento)
        {
            if (funciona == false)
                Console.WriteLine("La caldera {0} esta descompuesta", marca);
            else
            {
                tempActual += pAumento;
                Console.WriteLine("La temperatura actual es de {0}", tempActual);
                if (tempActual > tempMax)
                {
                    Console.WriteLine("{0} supero la temperatura, tiene {1}", marca, tempActual);
                    tempActual = tempMax;
                    funciona = false;
                    //Lanzamos la excepcion
                    // Y tenemos una variable  para la instancia
                    Exception ex = new Exception(string.Format("La caldera {0} se sobrecalenta", marca));
                    ex.HelpLink = "http://www.nicosiored.com";
                    // Adicionamos datos propios a la excepcion
                    ex.Data.Add("Momento: ", string.Format("Ocurrio en {0}", DateTime.Now));
                    ex.Data.Add("Temperatura acual: ", string.Format("{0} grados", tempActual));
                    ex.Data.Add("Incremento dado: ", string.Format("{0} grados", pAumento));
                    throw ex;
                }
            }
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            CCaldera miCaldera = new CCaldera("Matic-O", 20);

            ////V1
            //for (int i = 0; i < 10; i++)
            //    miCaldera.Trabajar(20);

            //// V2
            //try
            //{
            //    for (int i = 0; i < 10; i++)
            //        miCaldera.Trabajar(20);
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine("\nSucedio la excepcion");
            //    Console.WriteLine("En este metodo: {0}", e.TargetSite);
            //    Console.WriteLine("Con este mensaje de error: {0}", e.Message);
            //    Console.WriteLine("Fuente: {0}", e.Source);

            //    Console.WriteLine("Clase donde ocurrio: {0}", e.TargetSite.DeclaringType);
            //    Console.WriteLine("Tipo de miembro: {0}", e.TargetSite.MemberType);

            //    Console.WriteLine("Stack: {0}", e.StackTrace);
            //}

            // V3
            try
            {
                for (int i = 0; i < 10; i++)
                    miCaldera.Trabajar(20);
            }
            catch (Exception e)
            {
                Console.WriteLine("\nSucedio la excepcion");
                Console.WriteLine("En este metodo: {0}", e.TargetSite);
                Console.WriteLine("Con este mensaje de error: {0}", e.Message);
                Console.WriteLine("Fuente: {0}", e.Source);

                Console.WriteLine("Clase donde ocurrio: {0}", e.TargetSite.DeclaringType);
                Console.WriteLine("Tipo de miembro: {0}", e.TargetSite.MemberType);

                Console.WriteLine("Stack: {0}", e.StackTrace);
                Console.WriteLine("Help Link: {0}", e.HelpLink);

                Console.WriteLine("Mostramos los datos propios");
                // Verificamos que existan datos
                if(e.Data != null)
                {
                    // Imprimimos los datos extra propios
                    foreach (DictionaryEntry dato in e.Data)
                    {
                        Console.WriteLine("-> {0} -> {1}", dato.Key, dato.Value);
                    }
                }
            }
        }
    }
}
