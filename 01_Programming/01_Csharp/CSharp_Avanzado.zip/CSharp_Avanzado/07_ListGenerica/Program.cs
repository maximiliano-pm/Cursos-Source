﻿using System;
using System.Collections.Generic;

namespace _07_ListGenerica
{
    class Program
    {
        static void Main(string[] args)
        {
            List<int> valores = new List<int>();
            int r = 0;

            valores.Add(7);
            valores.Add(5);
            valores.Add(4);
            valores.Add(3);
            valores.Add(8);
            valores.Add(9);

            // Recorremos con ciclo for
            for (int n = 0; n < valores.Count; n++)
            {
                // No hay necesidad de type cast
                r = valores[n];
                Console.WriteLine(r);
            }
            Console.WriteLine("------------");

            // Vemos si contiene a determinado elemento
            Console.WriteLine(valores.Contains(5));
            Console.WriteLine(valores.Contains(17));
            Console.WriteLine("------------");

            // Obtenemos indice de un elemento
            Console.WriteLine(valores.IndexOf(4)); // Cuando el elemento no existe regresa -1
            Console.WriteLine("------------");

            // Insertamos elemento en un indice
            valores.Insert(2, 55);
            foreach (int valor in valores)
                Console.WriteLine(valor);
            Console.WriteLine("------------");

            // Eliminamos elemento en un indic
            valores.RemoveAt(3);
            foreach (int valor in valores)
                Console.WriteLine(valor);
            Console.WriteLine("------------");

            // Eliminamos la primera ocurrencia de un valor
            valores.Remove(8);
            foreach (int valor in valores)
                Console.WriteLine(valor);
            Console.WriteLine("------------");

            // La lisa se coloca en sentido contrario
            valores.Reverse();
            foreach (int valor in valores)
                Console.WriteLine(valor);
            Console.WriteLine("------------");

            // Mandamos a ordenar la lista
            valores.Sort();
            foreach (int valor in valores)
                Console.WriteLine(valor);
            Console.WriteLine("------------");

            // Creamos una lista para nuestra clase
            List<CPunto> listaPuntos = new List<CPunto>();

            listaPuntos.Add(new CPunto(5, 3));
            listaPuntos.Add(new CPunto(7, 8));
            listaPuntos.Add(new CPunto(12, 5));
            listaPuntos.Add(new CPunto(6, 2));
            foreach (CPunto punto in listaPuntos)
                Console.WriteLine(punto);

            // No funciona por que no hemos implementado IComparable
            //listaPuntos.Sort();

            List<CPunto> puntos = new List<CPunto>
            {
                new CPunto(2,3),
                new CPunto(5,23),
                new CPunto(7,9)
            };
            foreach (CPunto p in puntos)
                Console.WriteLine(p);
            Console.WriteLine("-------");

            // Adicionamos un punto
            puntos.Add(new CPunto(45, 90)); foreach (CPunto p in puntos)
                Console.WriteLine(p);
            Console.WriteLine("-------");

            // Insertamos un punto
            puntos.Insert(2, new CPunto(100, 150));
            foreach (CPunto p in puntos)
                Console.WriteLine(p);
            Console.WriteLine("-------");

            // Copiamos de lista a arreglo
            CPunto[] arregloPuntos = puntos.ToArray();
            for (int n = 0; n < arregloPuntos.Length; n++)
            {
                Console.WriteLine(arregloPuntos[n]);
            }
            Console.WriteLine("-------------");
        }
    }
    class CPunto
    {
        private int x, y;
        public CPunto(int px, int py)
        {
            x = px;
            y = py;
        }
        public override string ToString()
        {
            return string.Format("X={0}, Y={1}", x, y);
        }
    }
}
