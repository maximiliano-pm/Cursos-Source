﻿using System;

namespace _22_ObjetoImplementaInterfaz
{
    interface IElectronico
    {
        void Encender(bool interruptor);
    }
    class CTelevisor : IElectronico
    {
        string marca;
        public CTelevisor(string pMarca)
        {
            marca = pMarca;
        }
        public override string ToString()
        {
            return string.Format("El televisor es marca {0}", marca);
        }
        public void Encender(bool interruptor)
        {
            if (interruptor)
                Console.WriteLine("Encendido");
            else
                Console.WriteLine("Apagado");
        }
    }
    class CPelota
    {
        string tamano;
        public CPelota(string pTamano)
        {
            tamano = pTamano;
        }
        public override string ToString()
        {
            return string.Format("El tamano de la pelota es {0}", tamano);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Como reconocer si un objeto implementa a determinada interfaz
            CTelevisor miTele = new CTelevisor("Sharpy");
            CPelota miPelota = new CPelota("Grande");
            IElectronico objeto = null;

            // Metodo 1, por excepcion
            try
            {
                Console.WriteLine("Probamos tele");
                objeto = (IElectronico)miTele;
                objeto.Encender(true);
            }
            catch (InvalidCastException e)
            {
                Console.WriteLine(e.Message);                
            }
            try
            {
                Console.WriteLine("Probamos la pelota");
                objeto = (IElectronico)miPelota;
                objeto.Encender(true);
            }
            catch (InvalidCastException e)
            {
                Console.WriteLine(e.Message);
            }
            Console.WriteLine("----------");
            // Metodo 2, por as (puede ser tratado como)
            Console.WriteLine("Probamos tele");
            objeto = miTele as IElectronico;
            if (objeto != null)
                objeto.Encender(true);
            else
                Console.WriteLine("No implementa IElectronico");

            Console.WriteLine("Probamos pelota");
            objeto = miPelota as IElectronico;
            if (objeto != null)
                objeto.Encender(true);
            else
                Console.WriteLine("No implementa IElectronico");
            Console.WriteLine("----------");

            // Metodo 3, por is (es p es compatible con)
            if (miTele is IElectronico)
                miTele.Encender(true);
            else
                Console.WriteLine("No implementa IElectronico");

            if (miPelota is IElectronico)
                Console.WriteLine("Wow, tienes una pelota electronica");
            else
                Console.WriteLine("No implementa IElectronico");
        }
    }
}
