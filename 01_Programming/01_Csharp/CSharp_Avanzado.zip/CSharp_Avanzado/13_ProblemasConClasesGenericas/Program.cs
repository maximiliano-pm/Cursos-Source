﻿using System;

namespace _13_ProblemasConClasesGenericas
{
    class COperaciones <T>
    {
        // Como se usan tipos genericos el compilador no sabe si T tiene sobrecarga de operadores por eso
        // marca error, se puede evitar con Dynamic pero no asegura que haya errores

        //public T Suma(T a, T b)
        //{
        //    return a + b;
        //}
        public T Suma(T a, T b)
        {
            dynamic da = a, db = b;
            return da + db;
        }
        //public T Resta(T a, T b)
        //{
        //    return a - b;
        //}
        public T Resta(T a, T b)
        {
            dynamic da = a, db = b;
            return da - db;
        }
        //public T Div(T a, T b)
        //{
        //    return a / b;
        //}
        public T Div(T a, T b)
        {
            dynamic da = a, db = b;
            return da / db;
        }
        //public T Multi(T a, T b)
        //{
        //    return a * b;
        //}
        public T Multi(T a, T b)
        {
            dynamic da = a, db = b;
            return da * db;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Ver la clase COperaciones, no es posible compilar
            // Usamos dynamic para resolverlo, el tipo se checa en ejecucion y no en compilacion

            COperaciones<int> miOperacion = new COperaciones<int>();
            COperaciones<string> miOperacionS = new COperaciones<string>();

            Console.WriteLine(miOperacion.Suma(5, 4));
            Console.WriteLine(miOperacionS.Suma("hola", " a todos"));

            //Console.WriteLine(miOperacionS.Multi("hola", " a todos"));
        }
    }
}
