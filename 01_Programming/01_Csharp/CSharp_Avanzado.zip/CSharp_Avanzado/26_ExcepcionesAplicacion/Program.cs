﻿using System;

namespace _26_ExcepcionesAplicacion
{
    class CCaldera
    {
        private int tempMax = 120;
        private int tempActual = 0;
        private string marca = "";
        private bool funciona = true;
        public int Temperatura { get => tempActual; set => tempActual = value; }
        public string Marca { get => marca; set => marca = value; }
        public bool Funciona { get => funciona; }
        public CCaldera(string pMarca, int pTemp)
        {
            tempActual = pTemp;
            marca = pMarca;
        }
        // V3
        public void Trabajar(int pAumento)
        {
            if (funciona == false)
                Console.WriteLine("La caldera {0} esta descompuesta", marca);
            else
            {
                tempActual += pAumento;
                Console.WriteLine("La temperatura actual es de {0}", tempActual);
                if (tempActual > tempMax)
                {
                    Console.WriteLine("{0} supero la temperatura, tiene {1}", marca, tempActual);
                    tempActual = tempMax;
                    funciona = false;

                    // Primera version de la excepcion propia
                    // Creamos una instancia de nuestra clase excepcion
                    CalderaExcepcion ex = new CalderaExcepcion(
                        string.Format("La caldera {0} se ha sobrecalentado", marca),
                        "Ha trabajado demasiado tiempo",
                        DateTime.Now);
                    // Colocamos un link de ayuda
                    ex.HelpLink = "http://www.nicosiored.com";
                    throw ex;
                }
            }
        }       
    }
    // V1 de la clase excepcion
    // Todas las clases de excepcion propias deben de tener acceso publico
    //public class CalderaExcepcion : ApplicationException
    //{
    //    private string mensaje = "";
    //    private DateTime momento;
    //    private string causa;
    //    public DateTime Momento { get => momento; set => momento = value; }
    //    public string Causa { get => causa; set => causa = value; }
    //    public CalderaExcepcion(string pMensaje, string pCausa, DateTime pMomento)
    //    {
    //        mensaje = pMensaje;
    //        causa = pCausa;
    //        momento = pMomento;
    //    }
    //    // Hacemos un overrired a la propiedade Excepcion.Message
    //    public override string Message => string.Format("Mensaje de la excepcion => {0}", mensaje);
    //}

    // V2
    // No es necesario hacer override de Message si pasamos la clase padre la info
    // en el contructor
    //public class CalderaExcepcion : ApplicationException
    //{
    //    private DateTime momento;
    //    private string causa;
    //    public DateTime Momento { get => momento; set => momento = value; }
    //    public string Causa { get => causa; set => causa = value; }
    //    public CalderaExcepcion(string pMensaje, string pCausa, DateTime pMomento) : base(pMensaje)
    //    {            
    //        causa = pCausa;
    //        momento = pMomento;
    //    }        
    //}

    // V3
    // Excepcion completa de acuerdo con las reglas de .NET
    // Derivar de Excepcion/ApplicationException
    // Usar [System.Serializable]
    // Definir un constructor de default
    // Definir un constructor que coloca Message en la herencia
    // Definir un constructor que maneja excepciones internas
    // Definir un constructor que maneja la serializacion del objeto
    [Serializable]
    public class CalderaExcepcion : ApplicationException
    {
        public CalderaExcepcion() { } // Contructor default
        public CalderaExcepcion(string pMensaje) : base(pMensaje) { } // Contructor Message
        public CalderaExcepcion(string pMensaje, System.Exception inner) : base(pMensaje, inner) { } // Ctor excep. internas
        protected CalderaExcepcion(
            System.Runtime.Serialization.SerializationInfo info,
            System.Runtime.Serialization.StreamingContext context)
            : base(info, context) { } // Constructor que maneja serializacion

        //Aqui propiedades adicionales
        private DateTime momento;
        private string causa;
        public DateTime Momento { get => momento; set => momento = value; }
        public string Causa { get => causa; set => causa = value; }
        public CalderaExcepcion(string pMensaje, string pCausa, DateTime pMomento) : base(pMensaje)
        {
            causa = pCausa;
            momento = pMomento;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Excepciones de aplicaciones
            // Necesitamos de cuatro entidades
            // Una clase que representa los detalles de la excepcion
            // Un miembro que lanza una instancia de la  excepcion
            // Un bloque de codigo que invaca el codigo que puede generar la excepcion
            // Un bloque que va a cachar o procesar la excepcion si es que ocurre

            //V1, V2, V3
            CCaldera miCaldera = new CCaldera("Matic-O", 20);
            Random rnd = new Random();

            while (miCaldera.Funciona)
            {
                try
                {
                    miCaldera.Trabajar(rnd.Next(10));
                }
                //catch (Exception e)
                //{
                //    Console.WriteLine("El mensaje: {0}", e.Message);
                //    throw;
                //}
                // Codigo para atrapar nuestra propia excepcion
                catch(CalderaExcepcion e)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(e.Message);
                    Console.WriteLine(e.Momento);
                    Console.WriteLine(e.Causa);
                    Console.ForegroundColor = ConsoleColor.White;
                }
            }
        }
    }
}