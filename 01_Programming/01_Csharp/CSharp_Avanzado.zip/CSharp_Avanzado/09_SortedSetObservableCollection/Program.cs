﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;

namespace _09_SortedSetObservableCollection
{
    class Program
    {
        static void Main(string[] args)
        {
            // SortedSet
            SortedSet<CPunto> puntos = new SortedSet<CPunto>();
            puntos.Add(new CPunto(3, 7));
            puntos.Add(new CPunto(8, 11));
            puntos.Add(new CPunto(2, 6));

            foreach (CPunto p in puntos)
                Console.WriteLine("->{0}", p);
            Console.WriteLine("--------------");

            puntos.Add(new CPunto(1, 15));
            puntos.Add(new CPunto(1, 2));
            foreach (CPunto p in puntos)
                Console.WriteLine("->{0}", p);
            Console.WriteLine("--------------");

            // Coleccion obervable
            // Necesita de using System.Collections.ObjectModel;
            // Se le puede adicionar un handler, para hacer algo cada vez que haya un cambio en la coleccion

            ObservableCollection<CPunto> puntosOb = new ObservableCollection<CPunto>()
            { new CPunto(4,55), new CPunto(17,22)};

            // Adicionamos el handler
            puntosOb.CollectionChanged += puntos_CollectionChanged;
            puntosOb.Add(new CPunto(2, 3));

            CPunto miPunto = new CPunto(5, 5);
            puntosOb.Add(miPunto);

            puntosOb.Remove(miPunto);
        }
        // Este es el handler que se invoca cuando cambia la coleccion
        static void puntos_CollectionChanged(object sender,System.Collections.Specialized.NotifyCollectionChangedEventArgs e)
        {
            // Vemos el tipo de evento que ocurrio
            Console.WriteLine("El evento es {0}", e.Action);

            // Si la accion es adicionar
            if (e.Action==System.Collections.Specialized.NotifyCollectionChangedAction.Add)
            {
                Console.WriteLine("Elementos nuevos");
                foreach (CPunto p in e.NewItems)
                    Console.WriteLine(p.ToString());
                Console.WriteLine();
            }
            // Si la accion fue remover
            if (e.Action == System.Collections.Specialized.NotifyCollectionChangedAction.Remove)
            {
                Console.WriteLine("Elementos afectados por el cambio");
                foreach (CPunto p in e.OldItems)
                    Console.WriteLine(p.ToString());
                Console.WriteLine();
            }
        }
    }
    class CPunto : IComparable<CPunto>
    {
        private int x, y;
        public CPunto(int px, int py)
        {
            x = px;
            y = py;
        }
        public override string ToString()
        {
            return string.Format("X={0}, Y={1}", x, y);
        }
        public int CompareTo(CPunto b)
        {
            double magA = Math.Sqrt(x * x + y * y);
            double magB = Math.Sqrt(b.x * b.x + b.y * b.y);
            if (magA > magB) 
                return 1;
            if (magA < magB) 
                return -1;
            else
                return 0;
        }
    }
}
