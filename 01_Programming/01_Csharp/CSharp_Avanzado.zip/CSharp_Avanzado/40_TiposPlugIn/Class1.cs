﻿using System;

namespace TiposPlugIn
{
    // En esta interface definimos los metodos que debe de implementar
    // el Plug-In
    public interface IPlugInMates
    {
        double Calcular(double pA, double pB);
    }
    // Indicamos que el atributo se usara solo en clases
    [AttributeUsage(AttributeTargets.Class)]
    public sealed class CInfoPlugIn : System.Attribute
    {
        private string creador;
        private string informacion;
        public string Creador { get => creador; set => creador = value; }
        public string Informacion { get => informacion; set => informacion = value; }
    }
}
