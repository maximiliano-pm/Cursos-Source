﻿using System;
// Despues de colocar la referecia ponemos el namespace
using Aritmetica;

namespace _32_Bibliotecas
{
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos el objeto de la bilblioteca
            MisMates mates = new MisMates(5, 3);
            double resultado = mates.suma();
            Console.WriteLine("El resultado de la suma es {0}", resultado);
            mates.multi();
            Console.WriteLine("El resultado de la multiplicacion es {0}", mates.R);

            Console.ReadKey();
        }
    }
}