﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _41_Dynamic
{
    class CConDynamic
    {
        // Un atributo dinamico
        private dynamic atributo;
        // Una propiedad dinamica
        public dynamic Propiedad { get => atributo; set => atributo = value; }
        public void imprime()
        {
            Console.WriteLine(atributo);
        }
        public void recibe(dynamic parametro)
        {
            Console.WriteLine("Recibi {0} ", parametro);
        }
        public dynamic regresa(int a)
        {
            if (a < 0)
                return 5;
            else
                return "Positivo";
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Forma de invocar miembros cuando se usa dynamic
            // Notar que intellisense no actua, cuidado con eso

            // Creemos una cadena en un dynamic
            dynamic texto = "Hola";

            // Podemos objetener una propiedad del tipo
            int n = texto.Length;

            // Podemos obtener una propiedad del tipo
            texto = texto.ToUpper();

            Console.WriteLine("{0}, {1}", n, texto);

            // Con dynamic no se verifica el error de sintaxis en el momento de compilacion
            // El error nos aparecera cuando se ejecute
            //n = texto.length;

            // Podemos incluso invocar metodos inexistentes sin error de compilacion
            //texto.nono(57);

            // Forma correcta de usar codigo con dynamic, usando try
            dynamic texto2 = "Nicosio";
            try
            {
                n = texto2.Length;
                texto2.ToUpper();
                Console.WriteLine("{0}, {1}", n, texto2);
                //texto2.toupper();
                CConDynamic objeto = new CConDynamic();
                objeto.Propiedad = 5;
                objeto.imprime();
                objeto.Propiedad = "Mas saludos";
                objeto.imprime();

                objeto.recibe(57.6);
                objeto.recibe("Otro test");

                dynamic regreso = objeto.regresa(10);
                Console.WriteLine(regreso);
            }
            catch (Microsoft.CSharp.RuntimeBinder.RuntimeBinderException ex)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine(ex);
                Console.ForegroundColor = ConsoleColor.White;
            }
            Console.ReadKey();
        }
    }
}
