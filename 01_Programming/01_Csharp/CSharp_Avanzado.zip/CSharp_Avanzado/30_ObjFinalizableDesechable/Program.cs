﻿using System;

namespace _30_ObjFinalizableDesechable
{
    // V1
    //class CPrueba : IDisposable
    //{
    //    private int a;
    //    public CPrueba(int pA)
    //    {
    //        a = pA;
    //    }
    //    public override string ToString()
    //    {
    //        return string.Format("El valor es {0}", a);
    //    }
    //    ~CPrueba()
    //    {
    //        Console.WriteLine("Estamos en destructor, aqui liberamos lo no administrado {0}", a);
    //    }
    //    public void Dispose()
    //    {
    //        Console.WriteLine("Estamos en Dispose, aqui liberamos lo no administrado {0}", a);
    //        // Si se uso dispose no debemos usar el destructor
    //        GC.SuppressFinalize(this);
    //    }
    //}

    // V2
    class CPrueba : IDisposable
    {
        // Para saber si se uso dispose
        private bool usoDispose = false;
        private int a;
        public CPrueba(int pA)
        {
            a = pA;
        }
        public override string ToString()
        {
            return string.Format("El valor es {0}", a);
        }
        ~CPrueba()
        {
            // Invocamos el metodo de limpieza
            Limpieza();
        }
        public void Dispose()
        {
            // Invocamos el metodo de limpieza
            // se coloca true por que se hace uso de dispose
            Limpieza();            
            // Como usamos dispose indicamos que no se use destructor
            GC.SuppressFinalize(this);
        }
        public void Limpieza()
        {
            if (usoDispose == false)
            {
                // Codigo de limpieza comun
                Console.WriteLine("Estamos en Limpieza, aqui liberamos lo no administrado {0}", a);
            }
            usoDispose = true;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Creamos objetos
            CPrueba objeto1 = new CPrueba(5);
            CPrueba objeto2 = new CPrueba(7);

            Console.WriteLine(objeto1);
            Console.WriteLine(objeto2);

            // Hacemos dispose de objeto1
            objeto1.Dispose();

            Console.WriteLine("--- Fin de programa ---");
        }
    }
}
