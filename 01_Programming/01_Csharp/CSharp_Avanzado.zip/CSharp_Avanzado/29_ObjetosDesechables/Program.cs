﻿using System;

namespace _29_ObjetosDesechables
{
    // Implementamos a IDisposable
    class CPrueba : IDisposable
    {
        private int a;
        public CPrueba(int pA)
        {
            a = pA;
        }
        public override string ToString()
        {
            return string.Format("El valor es {0}", a);
        }
        public void Dispose()
        {
            Console.WriteLine("Estamos en Dispose, aqui liberamos lo no administrado {0}", a);
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Si deseamos que los recursos no administrados seas liberados
            // tan pronto como se aposible en luar de que lo haga el recolector de basura
            // podemos implementar la interfaz IDisposable
            // En este caso se toma que cuando el usuario deja de usar al objeto,
            // el usuario invoca Dispose(), se libera lo no administrado, pero el objeto
            // sigue existiendo

            CPrueba objeto = new CPrueba(5);
            Console.WriteLine(objeto);
            objeto.Dispose();

            // Una mejor manera de hacerlo
            //if (objeto is IDisposable)
            //    objeto.Dispose();

            // Una forma de garantizar que Dispose es invocado
            //try
            //{
            //    Console.WriteLine(objeto);
            //}
            //finally
            //{
            //    objeto.Dispose();
            //}

            // Con esta tecnica Dispose es invocado automaticamente
            // Se puede listar varios objetos en el using
            using (CPrueba prueba2 = new CPrueba(7)) 
            {
                Console.WriteLine(prueba2);
            }
        }
    }
}