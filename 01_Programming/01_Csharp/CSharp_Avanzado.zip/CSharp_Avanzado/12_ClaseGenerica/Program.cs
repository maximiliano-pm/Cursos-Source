﻿using System;

namespace _12_ClaseGenerica
{
    // T representa al tipo con el que se trabajo en un momendo dado
    class CPunto<T>
    {
        // Creamos atributos de tipo T
        private T x;
        private T y;

        // Podemos recibir parametros de tipo T
        public CPunto(T px, T py)
        {
            x = px;
            y = py;
        }
        public override string ToString()
        {
            return string.Format("X={0}, Y={1}", x, y);
        }
        public void Reset()
        {
            // Colocamos el valor de default para el tipo T
            // Numericos 0
            // Referencias null
            x = default(T);
            y = default(T);
        }
        public void EncuentraTipo()
        {
            if (typeof(T) == typeof(int))
                Console.WriteLine("Trabajo como entero");
            else
                Console.WriteLine("Soy de otro tipo");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Para puntoI, T trabaja como int
            CPunto<int> puntoI = new CPunto<int>(3, 4);
            // Para puntoD, T trabaja como double
            CPunto<double> puntoD = new CPunto<double>(2.56, 1.87);
            // Para puntoF, T trabaja como float
            CPunto<float> puntoF = new CPunto<float>(9.98f, 7.69f);

            Console.WriteLine(puntoI);
            Console.WriteLine(puntoD);
            Console.WriteLine(puntoF);

            // Colocamos el valor de default
            puntoI.Reset();
            Console.WriteLine(puntoI);

            // Verificamos si esta trabajando con entero
            puntoI.EncuentraTipo();
            puntoD.EncuentraTipo();
        }
    }
}
