﻿using System;

namespace _20_MetodosExtension
{
    interface ISaludador
    {
        void Saludar();
    }
    class MiInt : ISaludador
    {
        private int a;
        public MiInt(int pA)
        {
            a = pA;
        }
        public override string ToString()
        {
            return string.Format("Tu int es {0}", a);
        }
        public void Saludar()
        {
            Console.WriteLine("Hola desde mi int {0}", a);
        }
    }
    // La clase donde se guardan las extensiones debe de ser estatica
    static class ClaseExtensiones
    {
        // El metodo que extiende debe de ser estatico
        // El primer parametro lleva this y representa al tipo que estamos
        // estendiendo
        public static bool EsPar(this int i)
        {
            if (i % 2 == 0)
                return true;
            else
                return false;
        }
        // Este extiende a un doble
        public static double Dobletea(this double d)
        {
            return d * 2.0;
        }
        // Este extiende solo a las clases que implementan ISaludador
        public static void Sonido(this ISaludador s)
        {
            Console.Beep();
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Este programa muestra el uso de metodos de extension

            // Extension del int
            int numero = 55;

            bool par = numero.EsPar(); // Aqui encontramos la extension!!!
            Console.WriteLine("{0} es {1}", numero, par);

            // Extension del double
            double valor = 55.19;

            Console.WriteLine(valor.Dobletea());

            // Extension7 ISaludador;
            MiInt entero = new MiInt(7);
            entero.Sonido();
        }
    }
}
