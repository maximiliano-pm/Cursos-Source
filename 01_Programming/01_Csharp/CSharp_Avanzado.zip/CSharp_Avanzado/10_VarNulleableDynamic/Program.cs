﻿using System;

namespace _10_VarNulleableDynamic
{
    class Program
    {
        static void Main(string[] args)
        {
            // Declaracion implicita de variables
            // Solo se permiten en variables locales
            // Nos e pueden usar en atributos
            // No se pueden usar como tipos de retorno
            // Se debe de colocar un valores en el momente de declaracion y no puede ser null
            // No confundir con var o Variant de otros lenguajes, es fuertemente tipificado
            // Se usan en LINQ donde un query puede dar un resultado dinamico

            var a = 5;
            var b = "Hola a toods";
            var c = 15.689;
            var d = false;
            //var e = null;
            var f = c;

            // Imprimirmos 
            Console.WriteLine(a);
            Console.WriteLine(b);
            Console.WriteLine(c);
            Console.WriteLine(d);

            // Usamos reflexion para conocer el tipo
            Console.WriteLine("a es {0}", a.GetType().Name);
            Console.WriteLine("b es {0}", a.GetType().Name);
            Console.WriteLine("c es {0}", a.GetType().Name);
            Console.WriteLine("d es {0}", a.GetType().Name);
            Console.WriteLine("f es {0}", a.GetType().Name);
            Console.WriteLine("-----------------------------");

            // Tipos nulleables
            // Los tipos nulleables pueden representar los mismos valores mas el valor null
            // Son utiles en bases de datos, pues podemos encontrar columnas no definidas
            // Para definirlo usamos ?
            // Pero realmente creamos una instancea de System.Nulleable<T>

            int? dato = 5;
            Console.WriteLine("dato {0}", dato);
            dato = null;
            Console.WriteLine("dato {0}", dato);

            double? precio = null;
            precio = 6.7;
            Console.WriteLine(precio);

            // El string no es nulleable ya que es un tipo por referencia
            //string? nombre = "Kevin"; // si se puede por defecto

            // Podemos saber si tiene o no tiene valor
            //precio = null;

            if (precio.HasValue)
                Console.WriteLine("Tiene valor {0}", precio.Value);
            else
                Console.WriteLine("No tiene valor");

            // El operador ?? nos permite asignar un valor en caso de que tenga null

            double? numero = asignador() ?? 5.55;
            // si asignador da null se asignara 5.55


            // Dynamic se puede ver como una forma de System.Object
            // en el sentido de que cualquier valor se puede asignar a dynamic  
            // La diferencia es que no es fuertemente tipificado
            // Se le puede asignar cualquier tipo al inicio y posteriormente 
            // asignar otro

            dynamic aa = 5;
            Console.WriteLine("Tipo {0}, valor {1}", a.GetType(), a);
            aa = "Hola a todos";
            Console.WriteLine("Tipo {0}, valor {1}", a.GetType(), a);

            // A diferencia de object, en dynamic se conoce el tipo hasta el 
            // tiempo de ejecucion
            // Dynamic se puede usar como tipo de retorno
            // No se puede usar en expresiones lambda o en metodos anonimos
            // Puede resultar utils si nos comunicamos con blibiotecas COM

        }
        public static double? asignador()
        {
            //return 4.5;
            return null;
        }
    }
}
