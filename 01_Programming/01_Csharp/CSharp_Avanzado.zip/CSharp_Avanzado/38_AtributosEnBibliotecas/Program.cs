﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Adicionar using correspondiente
using AritmeticaAtributos;

namespace _38_AtributosEnBibliotecas
{
    class Program
    {
        static void Main(string[] args)
        {
            // Usaremos reflexion con early binding
            // No olvidar adicionar la referencia

            // Obtenemos el tipo de la clase
            Type t = typeof(MisMates);

            // Obtenemos la lista de atributos
            object[] atributos = t.GetCustomAttributes(false);

            // Mostramos los atributos
            foreach (DatosAttribute atrubuto in atributos)
                Console.WriteLine("{0}", atrubuto.Dato);
            Console.ReadKey();
            {

            }
        }
    }
}
