﻿using System;

namespace _18_ConversionExplicita
{
    class CReal
    {
        private double r;
        public double R { get => r; set => r = value; }
        public CReal()
        {

        }
        public CReal(double pr)
        {
            r = pr;
        }
        public override string ToString()
        {
            return string.Format("r={0}", r);
        }
    }
    class CComplejo
    {
        private int a;
        private int b;
        public int A { get => a; set => a = value; }
        public int B { get => b; set => b = value; }
        public CComplejo(int pa, int pb)
        {
            a = pa;
            b = pb;
        }
        public override string ToString()
        {
            return string.Format("{0} + {1}i", a, b);
        }
        // Creamos una conversion explicita a reales
        public static explicit operator CReal(CComplejo pi) // De CComplejo a CReal
        {
            CReal temp = new CReal();
            temp.R = pi.a;
            return temp;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Conversion custom de tipo
            CComplejo comp1 = new CComplejo(2, 3);
            // no se puede
            //CReal real1 = comp1;

            // Tampoco se puede hasta que coloquemos el explicit
            CReal real2 = (CReal)comp1;
            Console.WriteLine(real2);
        }
    }
}