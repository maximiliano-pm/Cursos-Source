﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Diagnostics;

namespace _43_AppDomain
{
    class Program
    {
        static void Main(string[] args)
        {
            // Hacemos varias operaciones con los procesos de la maquina

            // Obtenemos la lista de procesos de la maquina
            var procesos = from proc in Process.GetProcesses()
                           orderby proc.Id
                           select proc;
            // Recorremos los procesos encontrados
            foreach (var proceso in procesos)
            {
                // Imprimir el ID y el nombre
                Console.WriteLine("PID: {0}, Nombre {1}", proceso.Id, proceso.ProcessName);
            }
            
            Console.WriteLine("-------------");

            //// Para obtener un proceso via su PID
            //Process miProceso = null;
            //int pid = 4264;
            //try
            //{
            //    miProceso = Process.GetProcessById(pid);
            //    Console.WriteLine("PID: {0}, Nombre {1}", miProceso.Id, miProceso.ProcessName);
            //    // Obtenemos la lista de hilos en el proceso
            //    ProcessThreadCollection hilos = miProceso.Threads;
            //    // Recorremos los hilos encontrados
            //    foreach (ProcessThread hilo in hilos)
            //    {
            //        Console.WriteLine("ID del hilo: {0}, Inicio: {1}, Prioridad: {2}",
            //            hilo.Id, hilo.StartTime, hilo.PriorityLevel);
            //    }
            //}
            //catch (Exception ex)
            //{
            //    Console.WriteLine(ex.Message);                
            //}

            //// Un modulo es un .dll o .exe alojado en un proceso
            //// Un sistema de 32 no puede acceder a modulos de 64, configurar correctamente
            //Console.WriteLine("Los modulos del proceso -- {0} -- son:", miProceso.ProcessName);
            //// Obtenemos los modulos
            //ProcessModuleCollection modulos = miProceso.Modules;
            //foreach (ProcessModule modulo in modulos)
            //{
            //    Console.WriteLine("Modulo: {0}", modulo.ModuleName);
            //}

            //Console.WriteLine("-------------");

            // Podemos iniciar y finalizar procesos
            Process otroProceso = null;
            try
            {
                // Iniciamos el proceso chrome.exe y le pasamos un parametro
                otroProceso = Process.Start("chrome.exe", "www.nicosio.com");
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine(ex.Message);                
            }
            Console.WriteLine("Oprime una tecla para continuar");
            Console.ReadLine();
            try
            {
                // Finalizamos el proceso
                otroProceso.Kill();
            }
            catch (InvalidOperationException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
