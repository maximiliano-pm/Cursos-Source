﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Reflection;
namespace _42_ReflexionDynamic
{
    class Program
    {
        static void Main(string[] args)
        {
            // Hay un runtime complementario conocido como DLR (Dynamic Language Runtime)
            // Permite descubrir los tipos en tiempo de ejecucion sin chequeos por parte
            // del compilador
            // Permite tener codigo muy flexible, tambien se puede trabajar con diferentes
            // plataformas y lenguajes de programacion
            // Permite adicionar o remover tipos de la memoria en tiempo de ejecucion

            // Hacemos uso de dynamic para simplificar la reflexion en el late binding

            try
            {
                // Cargamos el assembly
                Assembly asm = Assembly.Load("AritmeticaAtributos");

                // Obtenemos el metadato para el tipo deseado
                Type misMates = asm.GetType("AritmeticaAtributos.MisMates");

                // Creamos el objeto
                dynamic objeto = Activator.CreateInstance(misMates, new object[] { 5, 6 });

                // Hay que notar la simplificacion de la instancia
                // comparar con proyecto de Reflexion (35)
                // Invocamos el metodo
                objeto.suma();

                // Trabajamos con la propiedad
                double r = objeto.R;
                Console.WriteLine("El resultado es {0}", r);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);                
            }
            Console.ReadKey();
        }
    }
}