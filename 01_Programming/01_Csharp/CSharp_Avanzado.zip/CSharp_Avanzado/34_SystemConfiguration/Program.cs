﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace _34_SystemConfiguration
{
    class Program
    {
        static void Main(string[] args)
        {
            // Editamos App.Config y lo leemos dede la aplicacion

            // Creamos el objeto lector
            AppSettingsReader lector = new AppSettingsReader();

            // Leemos los datos con el type cast correcto
            string nombre = (string)lector.GetValue("Nombre", typeof(string));
            int edad = (int)lector.GetValue("Edad", typeof(int));

            Console.WriteLine("{0} tiene {1} de edad", nombre, edad);
            Console.ReadKey();
        }
    }
}
