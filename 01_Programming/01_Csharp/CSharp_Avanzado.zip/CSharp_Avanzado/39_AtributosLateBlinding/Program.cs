﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

// Necesitamos este namespace
using System.Reflection;
namespace _39_AtributosLateBlinding
{
    class Program
    {
        static void Main(string[] args)
        {
            // Usaremos la reflexion con late blinding
            // No olvidar copiar el .dll a la carpeta correspondiente
            try
            {
                // Cargamos assembly
                Assembly asm = Assembly.Load("AritmeticaAtributos");
                // Obtenemos el tipo del atributo
                Type datoAt = asm.GetType("AritmeticaAtributos.DatosAttribute");
                // Obtenemos el tipo de la propiedad
                PropertyInfo datoProp = datoAt.GetProperty("Dato");
                // Obtenemos la lista de tipos en  el assembly
                Type[] tipos = asm.GetTypes();
                // Para cada tipo en el assembly obtenemos el atributo
                foreach (Type t in tipos)
                {
                    object[] objetos = t.GetCustomAttributes(datoAt, false);
                    // Recorremos todos los atributos 
                    foreach (object obj in objetos)
                    {
                        Console.WriteLine("{0}, {1}", t.Name, datoProp.GetValue(obj, null));
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);           
            }
            Console.ReadKey();
        }
    }
}
