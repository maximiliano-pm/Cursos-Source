﻿using System;

namespace _23_ManejoInterfacesConMetodos
{
    interface IElectronico
    {
        void Encender(bool interruptor);
    }
    class CTelevisor : IElectronico
    {
        string marca;
        public CTelevisor(string pMarca)
        {
            marca = pMarca;
        }
        public override string ToString()
        {
            return string.Format("El televisor es marca {0}", marca);
        }
        public void Encender(bool interruptor)
        {
            if (interruptor)
                Console.WriteLine("Encendido");
            else
                Console.WriteLine("Apagado");
        }
    }
    class CRadio : IElectronico
    {
        string marca;
        public CRadio(string pMarca)
        {
            marca = pMarca;
        }
        public override string ToString()
        {
            return string.Format("El radio es marca {0}", marca);
        }
        public void Encender(bool interruptor)
        {
            if (interruptor)
                Console.WriteLine("Encendido");
            else
                Console.WriteLine("Apagado");
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Arreglos de interfaces

            IElectronico[] teles = { new CTelevisor("Charp"), new CTelevisor("Zony"), new CRadio("RCB"), new CTelevisor("Filips") };
            IElectronico aparatoCreado = null;

            for (int n = 0; n < teles.Length; n++)
                Console.WriteLine(teles[n]);
            Console.WriteLine("--------------");

            // Uso de interfaces con metodos
            CTelevisor miTv = new CTelevisor("Charp TV");
            CRadio miRadio = new CRadio("RCB Radio");
            Muestra(miRadio);
            Muestra(miTv);
            Console.WriteLine("--------------");

            // Metodo que regresa objeto que implementa la interfaz IELectronico
            aparatoCreado = CrearAparato();
            aparatoCreado.Encender(true);
            Console.WriteLine(aparatoCreado);
        }
        // Este metodo puede recibir cualquier objeto que implemente IElectronico
        static void Muestra(IElectronico aparato)
        {
            if (aparato is CTelevisor)
                Console.WriteLine("El televisor es {0}", aparato);
            if (aparato is CRadio)
                Console.WriteLine("El radio es {0}", aparato);
        }
        // Este metodo puede regresar cualquier objeto que implemente a IElectronico
        static IElectronico CrearAparato()
        {
            IElectronico aparato = null;
            string dato = string.Empty;
            int opcion = 0;

            Console.WriteLine("Que deseas crear? 1.-Tele, 2.-Radio");
            dato = Console.ReadLine();
            opcion = Convert.ToInt32(dato);
            if (opcion == 1)
            {
                Console.WriteLine("Dame la marca de la tele:");
                dato = Console.ReadLine();
                aparato = new CTelevisor(dato);
            }
            if (opcion == 2)
            {
                Console.WriteLine("Dame la marca de el radio:");
                dato = Console.ReadLine();
                aparato = new CRadio(dato);
            }
            return aparato;
        }
    }
}
