﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
// Necesario para la excepcion
using System.IO;

namespace _45_ControlDeAppDomain
{
    class Program
    {
        static void Main(string[] args)
        {
            AppDomain dAD = AppDomain.CurrentDomain;

            // Colocamos el handler para la carga de assembly
            dAD.AssemblyLoad += handlerCarga;

            // Colocamos el handler para la descarga del AppDomain
            dAD.ProcessExit += handlerDescarga;

            ListaAssemblies(dAD);

            // Creamos un AppDomain nuevo
            // No olvidar copiar Aritmetica.dll en la carpeta
            AppDomain nuevoAD = AppDomain.CreateDomain("NuestroAppDomain");

            // Cargamos un assembly en ese AppDomain
            try
            {
                nuevoAD.Load("Aritmetica");
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex.Message);                
            }
            ListaAssemblies(nuevoAD);

            AppDomain.Unload(nuevoAD);

            Console.ReadKey();
        }
        private static void ListaAssemblies(AppDomain pAd)
        {
            var assemblies = from asm in pAd.GetAssemblies()
                             orderby asm.GetName().Name
                             select asm;
            Console.WriteLine("Assemblies encontrados en {0}", pAd.FriendlyName);
            foreach (var asm in assemblies)
            {
                Console.WriteLine("Nombre: {0}, Version: {1}", asm.GetName().Name, asm.GetName().Version);
            }
        }
        // Handler para detectar carga de assembly
        public static void handlerCarga(System.Object o, AssemblyLoadEventArgs s)
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("   Se cargo {0}", s.LoadedAssembly.GetName().Name);
            Console.ForegroundColor = ConsoleColor.White;
        }
        // Handler para detectar cuando se sale del proceso al descargar el AppDomain
        public static void handlerDescarga(System.Object o, EventArgs e)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("   Se descargo el AppDomain");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}
