﻿using System;
// Adicionamos este namespace
using TiposPlugIn;

namespace PlugInSumatoria
{
    // No olvidar hacer la referencia a TiposPlugIn

    // Colocamos el atributo
    [CInfoPlugIn(Creador = "Nicosio", Informacion = "Regresa doble, 1er operando valor, segundo poner 0")]
    // Creamos la clase que implementa la interfaz
    public class CSumatoria : IPlugInMates
    {
        public double Calcular(double pA, double pB)
        {
            int n = 0;
            double sumatoria = 0;
            for (n = 1; n <= pA; n++)
                sumatoria += n;
            return sumatoria;
        }
    }
}
