﻿using System;

namespace _27_MultiplesExcepciones
{
    class CCaldera
    {
        private int tempMax = 120;
        private int tempActual = 0;
        private string marca = "";
        private bool funciona = true;
        public int Temperatura { get => tempActual; set => tempActual = value; }
        public string Marca { get => marca; set => marca = value; }
        public bool Funciona { get => funciona; }
        public CCaldera(string pMarca, int pTemp)
        {
            tempActual = pTemp;
            marca = pMarca;
        }
        // V3
        public void Trabajar(int pAumento)
        {
            // Aqui colocamos una excepcion para argumento invalido
            if (pAumento < 0)
                throw new ArgumentOutOfRangeException("Aumento", "El aumento no puede ser negativo");
            if (funciona == false)
                Console.WriteLine("La caldera {0} esta descompuesta", marca);
            else
            {
                tempActual += pAumento;
                Console.WriteLine("La temperatura actual es de {0}", tempActual);
                if (tempActual > tempMax)
                {
                    Console.WriteLine("{0} supero la temperatura, tiene {1}", marca, tempActual);
                    tempActual = tempMax;
                    funciona = false;

                    // Primera version de la excepcion propia
                    // Creamos una instancia de nuestra clase excepcion
                    CalderaExcepcion ex = new CalderaExcepcion(
                        string.Format("La caldera {0} se ha sobrecalentado", marca),
                        "Ha trabajado demasiado tiempo",
                        DateTime.Now);
                    // Colocamos un link de ayuda
                    ex.HelpLink = "http://www.nicosiored.com";
                    throw ex;
                }
            }
        }
    }
    public class CalderaExcepcion : ApplicationException
    {
        private DateTime momento;
        private string causa;
        public DateTime Momento { get => momento; set => momento = value; }
        public string Causa { get => causa; set => causa = value; }
        public CalderaExcepcion(string pMensaje, string pCausa, DateTime pMomento) : base(pMensaje)
        {
            causa = pCausa;
            momento = pMomento;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {
            // Multiples excepciones 

            
            CCaldera miCaldera = new CCaldera("Matic-O", 20);
            Random rnd = new Random();

            //V1
            //while (miCaldera.Funciona)
            //{
            //    try
            //    {
            //        // Forzamos una excepcion de arugmento fuera de rango
            //        miCaldera.Trabajar(-10);
            //    } 
            //    // No se puede poner la excepcion mas general al inicio, nunca se ejecutaran las otras, el compilador no lo permite
            //    //catch(Exception e)
            //    //{
            //    //    Console.WriteLine(e.Message);
            //    //}
            //    catch (CalderaExcepcion e)
            //    {                    
            //        Console.WriteLine(e.Message);
            //    }
            //    catch (ArgumentOutOfRangeException e)
            //    {
            //        Console.WriteLine(e.Message);
            //    }
            //}

            //V2
            // Siempre de las mas particular a la mas general
            //while (miCaldera.Funciona)
            //{
            //    try
            //    {
            //        // Forzamos una excepcion de arugmento fuera de rango
            //        miCaldera.Trabajar(-10);
            //    }                
            //    catch (CalderaExcepcion e)
            //    {
            //        Console.WriteLine(e.Message);
            //    }
            //    catch (ArgumentOutOfRangeException e)
            //    {
            //        Console.WriteLine(e.Message);
            //    }
            //    // Ahora el catch captura cualquier excepcion
            //    // que no este arriba 
            //    catch (Exception e)
            //    {
            //        Console.WriteLine(e.Message);
            //    }
            //}

            // V3
            // Atrapamiento generico
            //    try
            //    {
            //        // Forzamos una excepcion de arugmento fuera de rango
            //        miCaldera.Trabajar(-10);
            //    }
            //    catch
            //    {
            //        // El catch no lleva referencia de alguna excepcion
            //        Console.WriteLine("Algo salio mal, pero no sabemos por que");
            //    }               

            // V4
            // Se pueden tener excepciones anidades
            //try
            //{
            //    // Forzamos una excepcion de arugmento fuera de rango
            //    miCaldera.Trabajar(-10);
            //    // Anidamos las excepciones
            //    try
            //    {
            //        miCaldera.Trabajar(300);
            //    }
            //    catch (CalderaExcepcion e)
            //    {
            //        Console.WriteLine(e.Message);                    
            //    }
            //}
            //catch (ArgumentOutOfRangeException e)
            //{
            //    Console.WriteLine(e.Message);                
            //}

            // V5
            // Uso de Finally                            
            //try
            //{
            //    // Forzamos una excepcion de arugmento fuera de rango
            //    miCaldera.Trabajar(-10);
            //}
            //catch (CalderaExcepcion e)
            //{
            //    Console.WriteLine(e.Message);
            //}
            //catch (ArgumentOutOfRangeException e)
            //{
            //    Console.WriteLine(e.Message);
            //}
            //finally
            //{
            //    Console.WriteLine("Este es el codigo comun en Finally");
            //}

            // V6
            // Esto pasa cuando no manejamos las excepciones
            // Forzamos una excepcion de arugmento fuera de rango
            // miCaldera.Trabajar(-10);
        }
    }
}