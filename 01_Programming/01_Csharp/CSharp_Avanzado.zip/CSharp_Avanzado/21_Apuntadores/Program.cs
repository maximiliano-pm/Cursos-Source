﻿using System;

namespace _21_Apuntadores
{
    class Program
    {
        static void Main(string[] args)
        {
            // Apuntadores
            // Es necesario poner el proyecto en unsafe
            // Guardan la direccion de memoria
            unsafe
            {
                // * - a donde apunta
                // & - direccion de
                int valor = 5;
                
                // Creo apuntador
                int* p;

                // Hago que apunte a la direccion de valor
                p = &valor;

                Console.WriteLine(*p);

                // Cambiamos el valor
                *p = 67;
                Console.WriteLine(*p);
                Console.WriteLine(valor);
            }
            // Aqui codigo fuera de unsage
            Console.WriteLine("--- Haremos un swap ---");
            int a = 3;
            int b = 8;
            Console.WriteLine("a={0}, b={1}", a, b);
            // Invocamos el metodo que usa apuntadores
            unsafe { swap(&a, &b); }
            Console.WriteLine("a={0}, b={1}", a, b);
        }
        // Creacion de un metodo que usa apuntadores
        unsafe public static void swap(int* n, int* m)
        {
            int temp = *m;
            *m = *n;
            *n = temp;
        }
    }
}
